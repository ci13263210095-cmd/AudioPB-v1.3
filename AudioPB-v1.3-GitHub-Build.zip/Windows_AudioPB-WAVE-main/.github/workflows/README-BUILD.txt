AudioPB v1.3 - GitHub Actions build

1. Upload this project to a GitHub repository.
2. Open the repository's Actions tab.
3. Select "Build AudioPB v1.3".
4. Click "Run workflow".
5. When the run finishes, open the workflow run and download the artifact named:
   AudioPB-v1.3-win64

The artifact contains:
- pb64.exe
- README-v1.3.TXT
- AudioPB-v1.3-win64.zip

The build uses GitHub's Windows runner and MSYS2 UCRT64 MinGW-w64.
